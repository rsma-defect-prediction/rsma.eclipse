#' Eclipse datasets for rsma
#'
#' This package contains 8 datasets for software defect prediction: \cr
#' \code{\link[rsma.eclipse]{eclipse_bug}} \cr
#' \code{\link[rsma.eclipse]{eclipse_change}} \cr
#' \code{\link[rsma.eclipse]{eclipse_churn}} \cr
#' \code{\link[rsma.eclipse]{eclipse_ckoo}} \cr
#' \code{\link[rsma.eclipse]{eclipse_complexity}} \cr
#' \code{\link[rsma.eclipse]{eclipse_entropy}} \cr
#' \code{\link[rsma.eclipse]{eclipse_file}} \cr
#' \code{\link[rsma.eclipse]{eclipse_package}} \cr
#'
#' The software metrics in these datasets have been computed from 5 Java projects:
#' \itemize{
#'   \item Eclipse JDT Core: IDE for software developers.
#'   \item Equinox framework: for developing modular software programs and
#'         libraries. Connected to Eclipse main project.
#'   \item Apache Lucene: library providing indexing and search features.
#'   \item Mylyn: provides task management tools.
#'   \item Eclipse PDE UI: plug-in development environment to develop Eclipse
#'         features.
#' }
#'
#' @source
#' For the first 6 datasets: \link{https://bug.inf.usi.ch/index.php}. \cr
#' For the last 2 datasets: \link{https://www.st.cs.uni-saarland.de/softevo/bug-data/eclipse/}.
#'
#' @references
#' Marco D'Ambros, Michele Lanza, Romain Robbes: An
#' Extensive Comparison of Bug Prediction Approaches,
#' In Proceedings of MSR 2010 (7th IEEE Working Conference on Mining
#' Software Repositories), pp. 31 - 41. IEEE CS Press, 2010.
#'
#' Thomas Zimmermann, Rahul Premraj, and Andreas Zeller:
#' Predicting Defects for Eclipse, In Proceedings of the Third International
#' Workshop on Predictor Models in Software Engineering, May 2007.
#'
#' @docType package
#' @name rsma.eclipse
NULL



