#' eclipse_bug
#'
#' Bug metrics data set.
#'
#' These metrics rely on the assumption that the best predictor for future defects
#' is the number of past defects.
#'
#' @examples
#' eclipse_bug <- eclipse_bug[,3:8]
#'
#' @format The variables are:
#' \describe{
#'   \item{project}{The class belongs to Eclipse, Equinox, Lucene, Mylyn or PDE projects}
#'   \item{classname}{Name of the class}
#'   \item{numberOfBugsFoundUntil.}{Number of total bugs found before release}
#'   \item{numberOfNonTrivialBugsFoundUntil.}{Number of non trivial bugs found before release}
#'   \item{numberOfMajorBugsFoundUntil.}{Number of major bugs found before release}
#'   \item{numberOfCriticalBugsFoundUntil.}{Number of critical bugs found before release}
#'   \item{numberOfHighPriorityBugsFoundUntil.}{Number of high priority bugs found before release}
#'   \item{bugs}{Number of total bugs post release}
#'   \item{nonTrivialBugs}{Number of non trivial bugs post release}
#'   \item{majorBugs}{Number of major bugs post release}
#'   \item{criticalBugs}{Number of critical bugs post release}
#'   \item{highPriorityBugs}{Number of high priority bugs post release}
#' }
#'
#' @source \url{https://bug.inf.usi.ch/index.php}
"eclipse_bug"

#' eclipse_change
#'
#' Contains change metrics (based on the number of changes made such as lines added
#' or removed, number of fixes and refactorings, or age of the code) for software
#' defect prediction.
#'
#' These metrics are used for software defect prediction (supervised learning
#' models).
#'
#' @examples
#' eclipse_change <- eclipse_change[,3:18]
#'
#' @format
#' \describe{
#'   \item{project}{The class belongs to Eclipse, Equinox, Lucene, Mylyn or PDE projects}
#'   \item{classname}{The name of the class}
#'   \item{numberOfVersionsUntil.}{Number of versions (revisions) before last release}
#'   \item{numberOfFixesUntil.}{Number of fixes before last release}
#'   \item{numberOfRefactoringsUntil.}{Number of refactorings before last release}
#'   \item{numberOfAuthorsUntil.}{Number of authors before last release}
#'   \item{linesAddedUntil.}{Sum of all the lines added between all the revisions (before last release)}
#'   \item{maxLinesAddedUntil.}{Maximum number of lines added in a single revision}
#'   \item{avgLinesAddedUntil.}{Average number of lines added in a single revision}
#'   \item{linesRemovedUntil.}{Sum of all the lines removed between all the revisions (before last release)}
#'   \item{maxLinesRemovedUntil.}{Maximum number of lines removed in a single revision}
#'   \item{avgLinesRemovedUntil.}{Average number of lines removed in a single revision}
#'   \item{codeChurnUntil.}{How many times the class has been edited between all the revisions before last release}
#'   \item{maxCodeChurnUntil.}{Maximum number of times the class has been edited in a single revision}
#'   \item{avgCodeChurnUntil.}{Average number of times the class has been edited in a single revision}
#'   \item{ageWithRespectTo.}{Age of the class}
#'   \item{weightedAgeWithRespectTo.}{Weighted age of the class}
#'   \item{bugs}{Number of total bugs post release}
#'   \item{nonTrivialBugs}{Number of non trivial bugs post release}
#'   \item{majorBugs}{Number of major bugs post release}
#'   \item{criticalBugs}{Number of critical bugs post release}
#'   \item{highPriorityBugs}{Number of high priority bugs post release}
#' }
#'
#' @source \url{https://bug.inf.usi.ch/index.php}
"eclipse_change"

#' eclipse_churn
#'
#' Contains the code churn calculated for every CK and OO metric. The code churn
#' measures how frequently the metrics have changed in time. Classes with very high
#' code churn for many metrics will have more bugs.
#'
#' These metrics are used for software defect prediction (supervised learning
#' models).
#'
#' @examples
#' eclipse_churn <- eclipse_churn[,3:20]
#'
#' @format
#' \describe{
#'   \item{project}{The class belongs to Eclipse, Equinox, Lucene, Mylyn or PDE projects}
#'   \item{classname}{The name of the class}
#'   \item{cbo}{Code churn for cbo metric}
#'   \item{dit}{Code churn for dit metric}
#'   \item{fanIn}{Code churn for fanIn metric}
#'   \item{fanOut}{Code churn for fanOut metric}
#'   \item{lcom}{Code churn for lcom metric}
#'   \item{noc}{Code churn for noc metric}
#'   \item{numberOfAttributes}{Code churn for numberOfAttributes metric}
#'   \item{numberOfAttributesInherited}{Code churn for numberOfAttributesInherited metric}
#'   \item{numberOfLinesOfCode}{Code churn for numberOfLinesOfCode metric}
#'   \item{numberOfMethods}{Code churn for numberOfMethods metric}
#'   \item{numberOfMethodsInherited}{Code churn for numberOfMethodsInherited metric}
#'   \item{numberOfPrivateAttributes}{Code churn for numberOfPrivateAttributes metric}
#'   \item{numberOfPrivateMethods}{Code churn for numberOfPrivateMethods metric}
#'   \item{numberOfPublicAttributes}{Code churn for numberOfPublicAttributes metric}
#'   \item{numberOfPublicMethods}{Code churn for numberOfPublicMethods metric}
#'   \item{rfc}{Code churn for rfc metric}
#'   \item{wmc}{Code churn for wmc metric}
#'   \item{bugs}{Number of bugs found after last release}
#'   \item{nonTrivialBugs}{Number of non trivial bugs post release}
#'   \item{majorBugs}{Number of major bugs post release}
#'   \item{criticalBugs}{Number of critical bugs post release}
#'   \item{highPriorityBugs}{Number of high priority bugs post release}
#' }
#'
#' @source \url{https://bug.inf.usi.ch/index.php}
"eclipse_churn"

#' eclipse_ckoo
#'
#' Contains CK (from Chidamber & Kemerer software metrics suite) and other
#' object-oriented metrics. All the variables are numeric.
#'
#' These metrics are used for software defect prediction (supervised learning
#' models).
#'
#' @examples
#' eclipse_ckoo <- eclipse_ckoo[,3:20]
#'
#' @format The variables are:
#' \describe{
#'   \item{project}{The class belongs to Eclipse, Equinox, Lucene, Mylyn or PDE projects}
#'   \item{classname}{The name of the class}
#'   \item{cbo}{coupling between objects, it is the count of the other classes that are connected to the
#'   current one}
#'   \item{dit}{depth of inheritance tree, it measures the length between the root node of the inheritance
#'   tree and the node of the current class. In general, the higher this value the more complex the
#'   code is (because it relies on inherited classes), and so the more fault-prone the class becomes}
#'   \item{fanIn}{number of classes that reference the current class}
#'   \item{fanOut}{number of classes that are referenced by the current class}
#'   \item{lcom}{lack of cohesion methods, measures the number of methods pairs inside a class whose
#'   similarity is zero. High values of lcom means that the methods inside the class are very dissimilar
#'   to each other, and this adds a level of complexity that makes the class more fault-prone}
#'   \item{noc}{number of children, it is the number of subclasses immediately subordinate to the current
#'   class. A high value of noc means that the class is very important in the inheritance tree, because
#'   many other classes depend on it}
#'   \item{numberOfAttributes}{number of attributes in the class}
#'   \item{numberOfAttributesInherited}{number of attributes inherited by the class}
#'   \item{numberOfLinesOfCode}{number of lines of code of the current class}
#'   \item{numberOfMethods}{number of methods in the class}
#'   \item{numberOfMethodsInherited}{number of methods inherited}
#'   \item{numberOfPrivateAttributes}{number of private attributes. Private attributes are only accessible through the class in
#'   which they belong to}
#'   \item{numberOfPrivateMethods}{number of private methods. Private methods are only accessible through the class in
#'   which they belong to}
#'   \item{numberOfPublicAttributes}{number of public attributes. Public attributes can be accessed through classes other than
#'   the current one}
#'   \item{numberOfPublicMethods}{number of public methods. Public methods can be accessed through classes other than
#'   the current one}
#'   \item{rfc}{response for a class, counts the number of methods that can be executed when an object
#'   of the current class is called. If rfc is high, it means that many methods can be executed when
#'   calling an object of this class, therefore it makes the class more likely to be defective}
#'   \item{wmc}{weighted methods per class, sum of the complexities of the methods inside a class.
#'   Complexities can be of different types (such as McCabe’s Cyclomatic Complexity for example),
#'   but often they are set as 1 for each method: in this case, the value of wmc is just
#'   the number of methods in a class. In general the higher the value, the more fault-prone the class
#'   is}
#'   \item{bugs}{Number of bugs found after last release}
#'   \item{nonTrivialBugs}{Number of non trivial bugs post release}
#'   \item{majorBugs}{Number of major bugs post release}
#'   \item{criticalBugs}{Number of critical bugs post release}
#'   \item{highPriorityBugs}{Number of high priority bugs post release}
#' }
#'
#' @source \url{https://bug.inf.usi.ch/index.php}
"eclipse_ckoo"

#' eclipse_complexity
#'
#' Complexity (entropy related) metrics. Contains the metrics about entropy (complexity)
#' of code changes, meaning how distributed the changes are in a system. The more
#' the changes are spread in time, the more complex the system is. This contains
#' entropy information for the whole dataset, not for the single variables.
#'
#' These metrics are used for software defect prediction. This data set doesn't
#' have a bugs column. For a more in depth explanation of the variables, see
#' page 7 of D'Ambros paper.
#'
#' @format The variables are:
#' \describe{
#'   \item{project}{The class belongs to Eclipse, Equinox, Lucene, Mylyn or PDE projects}
#'   \item{classname}{The name of the class}
#'   \item{CvsEntropy}{History of complexity metric}
#'   \item{CvsWEntropy}{Weighted history of complexity metric}
#'   \item{CvsLinEntropy}{Linearly decayed history of complexity metric (the contributions given by every change decay linearly)}
#'   \item{CvsLogEntropy}{Logarithmically decayed history of complexity metric (the contributions given by every change decay logarithmically)}
#'   \item{CvsExpEntropy}{Exponentially decayed history of complexity metric (the contributions given by every change decay exponentially)}
#' }
#'
#' @source \url{https://bug.inf.usi.ch/index.php}
"eclipse_complexity"

#' eclipse_entropy
#'
#' Entropy metrics for each software metric.
#'
#' These metrics are used for software defect prediction (supervised learning
#' models).
#'
#' @examples
#' eclipse_entropy <- eclipse_entropy[,3:20]
#'
#' @format The variables are:
#' \describe{
#'   \item{project}{The class belongs to Eclipse, Equinox, Lucene, Mylyn or PDE projects}
#'   \item{classname}{The name of the class}
#'   \item{cbo}{Entropy for cbo metric}
#'   \item{dit}{Entropy for dit metric}
#'   \item{fanIn}{Entropy for fanIn metric}
#'   \item{fanOut}{Entropy for fanOut metric}
#'   \item{lcom}{Entropy for lcom metric}
#'   \item{noc}{Entropy for noc metric}
#'   \item{numberOfAttributes}{Entropy for numberOfAttributes metric}
#'   \item{numberOfAttributesInherited}{Entropy for numberOfAttributesInherited metric}
#'   \item{numberOfLinesOfCode}{Entropy for numberOfLinesOfCode metric}
#'   \item{numberOfMethods}{Entropy for numberOfMethods metric}
#'   \item{numberOfMethodsInherited}{Entropy for numberOfMethodsInherited metric}
#'   \item{numberOfPrivateAttributes}{Entropy for numberOfPrivateAttributes metric}
#'   \item{numberOfPrivateMethods}{Entropy for numberOfPrivateMethods metric}
#'   \item{numberOfPublicAttributes}{Entropy for numberOfPublicAttributes metric}
#'   \item{numberOfPublicMethods}{Entropy for numberOfPublicMethods metric}
#'   \item{rfc}{Entropy for rfc metric}
#'   \item{wmc}{Entropy for wmc metric}
#'   \item{bugs}{Number of bugs found after last release}
#'   \item{nonTrivialBugs}{Number of non trivial bugs post release}
#'   \item{majorBugs}{Number of major bugs post release}
#'   \item{criticalBugs}{Number of critical bugs post release}
#'   \item{highPriorityBugs}{Number of high priority bugs post release}
#' }
#'
#' @source \url{https://bug.inf.usi.ch/index.php}
"eclipse_entropy"

#' eclipse_file
#'
#' Contains complexity metrics and values for the abstract syntax tree nodes at the
#' file level. The variables preceded by "NORM" are normalized.
#'
#' These metrics are used for software defect prediction (supervised learning
#' models).
#'
#' @examples
#' eclipse_file <- eclipse_file[,4:203]
#' eclipse_file <- eclipse_file[,colSums(eclipse_file!=0)>0]
#' eclipse_file <- eclipse_file[,-c(47,67)]
#' eclipse_file <- data.frame(eclipse_file[,-2], eclipse_file[,2])
#' names(eclipse_file)[154] <- "post"
#'
#' @format The variables are:
#' \describe{
#'   \item{version}{Version of the Eclipse software analyzed: can be 2.0, 2.1 or 3.0}
#'   \item{plugin}{Plugin containing the file}
#'   \item{filename}{Name of the file}
#'   \item{pre}{Pre release number of defects}
#'   \item{post}{Post release number of defects}
#'   \item{ACD}{Number of anonymous type declarations}
#'   \item{FOUT_avg}{Average number of method calls}
#'   \item{FOUT_max}{Maximum number of method calls}
#'   \item{FOUT_sum}{Sum of all method calls}
#'   \item{MLOC_avg}{Average method lines of code}
#'   \item{MLOC_max}{Maximum method lines of code}
#'   \item{MLOC_sum}{Sum of all method lines of code}
#'   \item{NBD_avg}{Average nested block depth}
#'   \item{NBD_max}{Maximum nested block depth}
#'   \item{NBD_sum}{Sum of nested block depth}
#'   \item{NOF_avg}{Average number of fields}
#'   \item{NOF_max}{Maximum number of fields}
#'   \item{NOF_sum}{Sum of number of fields}
#'   \item{NOI}{Number of interfaces}
#'   \item{NOM_avg}{Average number of methods}
#'   \item{NOM_max}{Maximum number of methods}
#'   \item{NOM_sum}{Sum of number of methods}
#'   \item{NOT}{Number of classes}
#'   \item{NSF_avg}{Average number of static fields}
#'   \item{NSF_max}{Maximum number of static fields}
#'   \item{NSF_sum}{Sum of number of static fields}
#'   \item{NSM_avg}{Average number of static methods}
#'   \item{NSM_max}{Maximum number of static methods}
#'   \item{NSM_sum}{Sum of number of static methods}
#'   \item{PAR_avg}{Average number of parameters}
#'   \item{PAR_max}{Maximum number of parameters}
#'   \item{PAR_sum}{Sum of number of parameters}
#'   \item{TLOC}{Total lines of code}
#'   \item{VG_avg}{Average McCabe's cyclomatic complexity}
#'   \item{VG_max}{Maximum McCabe's cyclomatic complexity}
#'   \item{VG_sum}{Sum of McCabe's cyclomatic complexity}
#'   \item{AnonymousClassDeclaration}
#'   \item{ArrayAccess}
#'   \item{ArrayCreation}
#'   \item{ArrayInitializer}
#'   \item{ArrayType}
#'   \item{AssertStatement}
#'   \item{Assignment}
#'   \item{Block}
#'   \item{BooleanLiteral}
#'   \item{BreakStatement}
#'   \item{CastExpression}
#'   \item{CatchClause}
#'   \item{CharacterLiteral}
#'   \item{ClassInstanceCreation}
#'   \item{CompilationUnit}
#'   \item{ConditionalExpression}
#'   \item{ConstructorInvocation}
#'   \item{ContinueStatement}
#'   \item{DoStatement}
#'   \item{EmptyStatement}
#'   \item{ExpressionStatement}
#'   \item{FieldAccess}
#'   \item{FieldDeclaration}
#'   \item{ForStatement}
#'   \item{IfStatement}
#'   \item{ImportDeclaration}
#'   \item{InfixExpression}
#'   \item{Initializer}
#'   \item{Javadoc}
#'   \item{LabeledStatement}
#'   \item{MethodDeclaration}
#'   \item{MethodInvocation}
#'   \item{NullLiteral}
#'   \item{NumberLiteral}
#'   \item{PackageDeclaration}
#'   \item{ParenthesizedExpression}
#'   \item{PostfixExpression}
#'   \item{PrefixExpression}
#'   \item{PrimitiveType}
#'   \item{QualifiedName}
#'   \item{ReturnStatement}
#'   \item{SimpleName}
#'   \item{SimpleType}
#'   \item{SingleVariableDeclaration}
#'   \item{StringLiteral}
#'   \item{SuperConstructorInvocation}
#'   \item{SuperFieldAccess}
#'   \item{SuperMethodInvocation}
#'   \item{SwitchCase}
#'   \item{SwitchStatement}
#'   \item{SynchronizedStatement}
#'   \item{ThisExpression}
#'   \item{ThrowStatement}
#'   \item{TryStatement}
#'   \item{TypeDeclaration}
#'   \item{TypeDeclarationStatement}
#'   \item{TypeLiteral}
#'   \item{VariableDeclarationExpression}
#'   \item{VariableDeclarationFragment}
#'   \item{VariableDeclarationStatement}
#'   \item{WhileStatement}
#'   \item{InstanceofExpression}
#'   \item{LineComment}
#'   \item{BlockComment}
#'   \item{TagElement}
#'   \item{TextElement}
#'   \item{MemberRef}
#'   \item{MethodRef}
#'   \item{MethodRefParameter}
#'   \item{EnhancedForStatement}
#'   \item{EnumDeclaration}
#'   \item{EnumConstantDeclaration}
#'   \item{TypeParameter}
#'   \item{ParameterizedType}
#'   \item{QualifiedType}
#'   \item{WildcardType}
#'   \item{NormalAnnotation}
#'   \item{MarkerAnnotation}
#'   \item{SingleMemberAnnotation}
#'   \item{MemberValuePair}
#'   \item{AnnotationTypeDeclaration}
#'   \item{AnnotationTypeMemberDeclaration}
#'   \item{Modifier}
#'   \item{SUM}{Sum of all the abstract syntax tree nodes values}
#'   \item{NORM_AnonymousClassDeclaration}
#'   \item{NORM_ArrayAccess}
#'   \item{NORM_ArrayCreation}
#'   \item{NORM_ArrayInitializer}
#'   \item{NORM_ArrayType}
#'   \item{NORM_AssertStatement}
#'   \item{NORM_Assignment}
#'   \item{NORM_Block}
#'   \item{NORM_BooleanLiteral}
#'   \item{NORM_BreakStatement}
#'   \item{NORM_CastExpression}
#'   \item{NORM_CatchClause}
#'   \item{NORM_CharacterLiteral}
#'   \item{NORM_ClassInstanceCreation}
#'   \item{NORM_CompilationUnit}
#'   \item{NORM_ConditionalExpression}
#'   \item{NORM_ConstructorInvocation}
#'   \item{NORM_ContinueStatement}
#'   \item{NORM_DoStatement}
#'   \item{NORM_EmptyStatement}
#'   \item{NORM_ExpressionStatement}
#'   \item{NORM_FieldAccess}
#'   \item{NORM_FieldDeclaration}
#'   \item{NORM_ForStatement}
#'   \item{NORM_IfStatement}
#'   \item{NORM_ImportDeclaration}
#'   \item{NORM_InfixExpression}
#'   \item{NORM_Initializer}
#'   \item{NORM_Javadoc}
#'   \item{NORM_LabeledStatement}
#'   \item{NORM_MethodDeclaration}
#'   \item{NORM_MethodInvocation}
#'   \item{NORM_NullLiteral}
#'   \item{NORM_NumberLiteral}
#'   \item{NORM_PackageDeclaration}
#'   \item{NORM_ParenthesizedExpression}
#'   \item{NORM_PostfixExpression}
#'   \item{NORM_PrefixExpression}
#'   \item{NORM_PrimitiveType}
#'   \item{NORM_QualifiedName}
#'   \item{NORM_ReturnStatement}
#'   \item{NORM_SimpleName}
#'   \item{NORM_SimpleType}
#'   \item{NORM_SingleVariableDeclaration}
#'   \item{NORM_StringLiteral}
#'   \item{NORM_SuperConstructorInvocation}
#'   \item{NORM_SuperFieldAccess}
#'   \item{NORM_SuperMethodInvocation}
#'   \item{NORM_SwitchCase}
#'   \item{NORM_SwitchStatement}
#'   \item{NORM_SynchronizedStatement}
#'   \item{NORM_ThisExpression}
#'   \item{NORM_ThrowStatement}
#'   \item{NORM_TryStatement}
#'   \item{NORM_TypeDeclaration}
#'   \item{NORM_TypeDeclarationStatement}
#'   \item{NORM_TypeLiteral}
#'   \item{NORM_VariableDeclarationExpression}
#'   \item{NORM_VariableDeclarationFragment}
#'   \item{NORM_VariableDeclarationStatement}
#'   \item{NORM_WhileStatement}
#'   \item{NORM_InstanceofExpression}
#'   \item{NORM_LineComment}
#'   \item{NORM_BlockComment}
#'   \item{NORM_TagElement}
#'   \item{NORM_TextElement}
#'   \item{NORM_MemberRef}
#'   \item{NORM_MethodRef}
#'   \item{NORM_MethodRefParameter}
#'   \item{NORM_EnhancedForStatement}
#'   \item{NORM_EnumDeclaration}
#'   \item{NORM_EnumConstantDeclaration}
#'   \item{NORM_TypeParameter}
#'   \item{NORM_ParameterizedType}
#'   \item{NORM_QualifiedType}
#'   \item{NORM_WildcardType}
#'   \item{NORM_NormalAnnotation}
#'   \item{NORM_MarkerAnnotation}
#'   \item{NORM_SingleMemberAnnotation}
#'   \item{NORM_MemberValuePair}
#'   \item{NORM_AnnotationTypeDeclaration}
#'   \item{NORM_AnnotationTypeMemberDeclaration}
#'   \item{NORM_Modifier}
#'}
#'
#' @source \url{https://www.st.cs.uni-saarland.de/softevo/bug-data/eclipse/}
"eclipse_file"

#' eclipse_package
#'
#' Contains complexity metrics and values for the abstract syntax tree nodes at the
#' package level. The variables preceded by "NORM" are normalized.
#'
#' These metrics are used for software defect prediction (supervised learning
#' models).
#'
#' @examples
#' eclipse_package <- eclipse_package[,4:212]
#' eclipse_package <- eclipse_package[, colSums(eclipse_package != 0) > 0]
#' eclipse_package <- data.frame(eclipse_package[,-2], eclipse_package[,2])
#' names(eclipse_package)[167] <- "post"
#'
#' @format The variables are:
#' \describe{
#'   \item{version}{Version of the Eclipse software analyzed: can be 2.0, 2.1 or 3.0}
#'   \item{plugin}{Plugin containing the package}
#'   \item{packagename}{Name of the package}
#'   \item{pre}{Pre release number of defects}
#'   \item{post}{Post release number of defects}
#'   \item{ACD_avg}{Average number of anonymous type declarations}
#'   \item{ACD_max}{Maximum number of anonymous type declarations}
#'   \item{ACD_sum}{Sum of number of anonymous type declarations}
#'   \item{FOUT_avg}{Average number of method calls}
#'   \item{FOUT_max}{Maximum number of method calls}
#'   \item{FOUT_sum}{Sum of all method calls}
#'   \item{MLOC_avg}{Average method lines of code}
#'   \item{MLOC_max}{Maximum method lines of code}
#'   \item{MLOC_sum}{Sum of all method lines of code}
#'   \item{NBD_avg}{Average nested block depth}
#'   \item{NBD_max}{Maximum nested block depth}
#'   \item{NBD_sum}{Sum of nested block depth}
#'   \item{NOCU}{Number of files in a package}
#'   \item{NOF_avg}{Average number of fields}
#'   \item{NOF_max}{Maximum number of fields}
#'   \item{NOF_sum}{Sum of number of fields}
#'   \item{NOI}{Number of interfaces}
#'   \item{NOM_avg}{Average number of methods}
#'   \item{NOM_max}{Maximum number of methods}
#'   \item{NOM_sum}{Sum of number of methods}
#'   \item{NOT_avg}{Average number of classes}
#'   \item{NOT_max}{Maximum number of classes}
#'   \item{NOT_sum}{Sum of number of classes}
#'   \item{NSF_avg}{Average number of static fields}
#'   \item{NSF_max}{Maximum number of static fields}
#'   \item{NSF_sum}{Sum of number of static fields}
#'   \item{NSM_avg}{Average number of static methods}
#'   \item{NSM_max}{Maximum number of static methods}
#'   \item{NSM_sum}{Sum of number of static methods}
#'   \item{PAR_avg}{Average number of parameters}
#'   \item{PAR_max}{Maximum number of parameters}
#'   \item{PAR_sum}{Sum of number of parameters}
#'   \item{TLOC_avg}{Average number of lines of code}
#'   \item{TLOC_max}{Maximum number of lines of code}
#'   \item{TLOC_sum}{Sum of lines of code}
#'   \item{VG_avg}{Average McCabe's cyclomatic complexity}
#'   \item{VG_max}{Maximum McCabe's cyclomatic complexity}
#'   \item{VG_sum}{Sum of McCabe's cyclomatic complexity}
#'   \item{AnonymousClassDeclaration}
#'   \item{ArrayAccess}
#'   \item{ArrayCreation}
#'   \item{ArrayInitializer}
#'   \item{ArrayType}
#'   \item{AssertStatement}
#'   \item{Assignment}
#'   \item{Block}
#'   \item{BooleanLiteral}
#'   \item{BreakStatement}
#'   \item{CastExpression}
#'   \item{CatchClause}
#'   \item{CharacterLiteral}
#'   \item{ClassInstanceCreation}
#'   \item{CompilationUnit}
#'   \item{ConditionalExpression}
#'   \item{ConstructorInvocation}
#'   \item{ContinueStatement}
#'   \item{DoStatement}
#'   \item{EmptyStatement}
#'   \item{ExpressionStatement}
#'   \item{FieldAccess}
#'   \item{FieldDeclaration}
#'   \item{ForStatement}
#'   \item{IfStatement}
#'   \item{ImportDeclaration}
#'   \item{InfixExpression}
#'   \item{Initializer}
#'   \item{Javadoc}
#'   \item{LabeledStatement}
#'   \item{MethodDeclaration}
#'   \item{MethodInvocation}
#'   \item{NullLiteral}
#'   \item{NumberLiteral}
#'   \item{PackageDeclaration}
#'   \item{ParenthesizedExpression}
#'   \item{PostfixExpression}
#'   \item{PrefixExpression}
#'   \item{PrimitiveType}
#'   \item{QualifiedName}
#'   \item{ReturnStatement}
#'   \item{SimpleName}
#'   \item{SimpleType}
#'   \item{SingleVariableDeclaration}
#'   \item{StringLiteral}
#'   \item{SuperConstructorInvocation}
#'   \item{SuperFieldAccess}
#'   \item{SuperMethodInvocation}
#'   \item{SwitchCase}
#'   \item{SwitchStatement}
#'   \item{SynchronizedStatement}
#'   \item{ThisExpression}
#'   \item{ThrowStatement}
#'   \item{TryStatement}
#'   \item{TypeDeclaration}
#'   \item{TypeDeclarationStatement}
#'   \item{TypeLiteral}
#'   \item{VariableDeclarationExpression}
#'   \item{VariableDeclarationFragment}
#'   \item{VariableDeclarationStatement}
#'   \item{WhileStatement}
#'   \item{InstanceofExpression}
#'   \item{LineComment}
#'   \item{BlockComment}
#'   \item{TagElement}
#'   \item{TextElement}
#'   \item{MemberRef}
#'   \item{MethodRef}
#'   \item{MethodRefParameter}
#'   \item{EnhancedForStatement}
#'   \item{EnumDeclaration}
#'   \item{EnumConstantDeclaration}
#'   \item{TypeParameter}
#'   \item{ParameterizedType}
#'   \item{QualifiedType}
#'   \item{WildcardType}
#'   \item{NormalAnnotation}
#'   \item{MarkerAnnotation}
#'   \item{SingleMemberAnnotation}
#'   \item{MemberValuePair}
#'   \item{AnnotationTypeDeclaration}
#'   \item{AnnotationTypeMemberDeclaration}
#'   \item{Modifier}
#'   \item{SUM}{Sum of all the abstract syntax tree nodes values}
#'   \item{NORM_AnonymousClassDeclaration}
#'   \item{NORM_ArrayAccess}
#'   \item{NORM_ArrayCreation}
#'   \item{NORM_ArrayInitializer}
#'   \item{NORM_ArrayType}
#'   \item{NORM_AssertStatement}
#'   \item{NORM_Assignment}
#'   \item{NORM_Block}
#'   \item{NORM_BooleanLiteral}
#'   \item{NORM_BreakStatement}
#'   \item{NORM_CastExpression}
#'   \item{NORM_CatchClause}
#'   \item{NORM_CharacterLiteral}
#'   \item{NORM_ClassInstanceCreation}
#'   \item{NORM_CompilationUnit}
#'   \item{NORM_ConditionalExpression}
#'   \item{NORM_ConstructorInvocation}
#'   \item{NORM_ContinueStatement}
#'   \item{NORM_DoStatement}
#'   \item{NORM_EmptyStatement}
#'   \item{NORM_ExpressionStatement}
#'   \item{NORM_FieldAccess}
#'   \item{NORM_FieldDeclaration}
#'   \item{NORM_ForStatement}
#'   \item{NORM_IfStatement}
#'   \item{NORM_ImportDeclaration}
#'   \item{NORM_InfixExpression}
#'   \item{NORM_Initializer}
#'   \item{NORM_Javadoc}
#'   \item{NORM_LabeledStatement}
#'   \item{NORM_MethodDeclaration}
#'   \item{NORM_MethodInvocation}
#'   \item{NORM_NullLiteral}
#'   \item{NORM_NumberLiteral}
#'   \item{NORM_PackageDeclaration}
#'   \item{NORM_ParenthesizedExpression}
#'   \item{NORM_PostfixExpression}
#'   \item{NORM_PrefixExpression}
#'   \item{NORM_PrimitiveType}
#'   \item{NORM_QualifiedName}
#'   \item{NORM_ReturnStatement}
#'   \item{NORM_SimpleName}
#'   \item{NORM_SimpleType}
#'   \item{NORM_SingleVariableDeclaration}
#'   \item{NORM_StringLiteral}
#'   \item{NORM_SuperConstructorInvocation}
#'   \item{NORM_SuperFieldAccess}
#'   \item{NORM_SuperMethodInvocation}
#'   \item{NORM_SwitchCase}
#'   \item{NORM_SwitchStatement}
#'   \item{NORM_SynchronizedStatement}
#'   \item{NORM_ThisExpression}
#'   \item{NORM_ThrowStatement}
#'   \item{NORM_TryStatement}
#'   \item{NORM_TypeDeclaration}
#'   \item{NORM_TypeDeclarationStatement}
#'   \item{NORM_TypeLiteral}
#'   \item{NORM_VariableDeclarationExpression}
#'   \item{NORM_VariableDeclarationFragment}
#'   \item{NORM_VariableDeclarationStatement}
#'   \item{NORM_WhileStatement}
#'   \item{NORM_InstanceofExpression}
#'   \item{NORM_LineComment}
#'   \item{NORM_BlockComment}
#'   \item{NORM_TagElement}
#'   \item{NORM_TextElement}
#'   \item{NORM_MemberRef}
#'   \item{NORM_MethodRef}
#'   \item{NORM_MethodRefParameter}
#'   \item{NORM_EnhancedForStatement}
#'   \item{NORM_EnumDeclaration}
#'   \item{NORM_EnumConstantDeclaration}
#'   \item{NORM_TypeParameter}
#'   \item{NORM_ParameterizedType}
#'   \item{NORM_QualifiedType}
#'   \item{NORM_WildcardType}
#'   \item{NORM_NormalAnnotation}
#'   \item{NORM_MarkerAnnotation}
#'   \item{NORM_SingleMemberAnnotation}
#'   \item{NORM_MemberValuePair}
#'   \item{NORM_AnnotationTypeDeclaration}
#'   \item{NORM_AnnotationTypeMemberDeclaration}
#'   \item{NORM_Modifier}
#' }
#'
#' @source \url{https://www.st.cs.uni-saarland.de/softevo/bug-data/eclipse/}
"eclipse_package"
